---
name: da-legal-compliance-checklist
description: Apply this skill to every website built or launched on the Digital Allies CMS (cms.digitalallies.net). Run it before any site goes live, and whenever writing or reviewing a Privacy Policy or Terms of Service page. It covers five risk areas — AI disclosure, arbitration clause, data collection disclosure, tracking pixel disclosure, and DMCA/UGC copyright protection — with ready-to-use template language for each. Trigger this skill whenever building a new DA site, adding a contact form, chatbot, AI feature, comment section, review section, or file upload, or when the user mentions "legal checklist," "lawsuit checklist," "DMCA," "privacy policy," or "terms of service" in the context of a DA build.
version: 1.0.0
---

# DA Legal Compliance Checklist

## When to use this skill

Run this on every site built on the Digital Allies CMS. Use it:

- Before any site launch, no exceptions
- When writing or editing a Privacy Policy or Terms of Service page
- When a site gets a contact form, AI chatbot, AI-generated content, comment section, review section, or file upload
- When a client asks "do I need a privacy policy" or "am I covered legally"

This is a pre-launch gate, not an optional add-on. Skip nothing without checking it against the site's actual features first.

---

## The five risk areas

For each site, check which of these apply, then generate only the matching sections.

### 1. AI disclosure

**Trigger:** the site uses an AI chatbot, AI-written copy, AI product recommendations, or any AI-powered feature the visitor interacts with.

**Risk:** the FTC classifies undisclosed AI use as deceptive advertising. This is a civil penalty risk.

**Fix:** one sentence, placed in the Privacy Policy or directly on the page where the AI feature lives.

**Template:**
> This site uses AI-powered [tools / chat / content generation] to [help with X]. Responses are generated automatically and may not always be accurate.

---

### 2. Arbitration clause

**Trigger:** every site that has a Terms of Service page. This applies to all of them.

**Risk:** without it, one unhappy user can organize a class action against the client. A single clause closes this door.

**Fix:** add to the Terms of Service.

**Template:**
> All disputes arising out of or in connection with this agreement shall be settled by arbitration under the Rules of Arbitration of the International Chamber of Commerce, by one or more arbitrators appointed in accordance with those Rules. You agree to resolve any dispute on an individual basis and waive any right to participate in a class action.

---

### 3. Data collection disclosure

**Trigger:** every site that uses cookies, contact forms, analytics, or e-commerce. This applies to almost all DA sites.

**Risk:** CCPA liability for undisclosed data collection.

**Fix:** list every data type the site actually collects in the Privacy Policy. Do not copy a generic list — fill this in per client based on what the site does.

**Data table to complete for each site:**

| Data type | Collected? | Purpose |
|---|---|---|
| Contact info (name, email, phone) | | |
| Location | | |
| Purchase history | | |
| Browsing behavior | | |
| Device / browser identifiers | | |

---

### 4. Tracking pixel disclosure

**Trigger:** Google Analytics, Meta Pixel, or any third-party tracking script is installed on the site.

**Risk:** CCPA liability for undisclosed tracking.

**Fix:** name the specific tools in the Privacy Policy. Do not use a vague "we may use cookies" line — name the actual tools installed on that site.

**Template:**
> We use [Google Analytics / Meta Pixel / name the actual tools] to understand site traffic and ad performance. These tools may collect your IP address and browsing behavior. You can opt out through your browser settings or ad preferences.

---

### 5. UGC / copyright liability

**Trigger:** the site lets users upload photos, videos, audio, text, comments, or reviews.

**Risk:** up to $150,000 per work in statutory damages if a user uploads copyrighted material and the client gets sued for it.

**Fix, two parts:**

1. The client registers a DMCA designated agent at copyright.gov. Costs $6. This must use the client's own business info, since they're the one operating the site — flag this as a manual step for the client to complete, not something the CMS can automate.
2. Add a takedown clause to the Terms of Service.

**Template:**
> If you believe content on this site infringes your copyright, send a notice to our designated DMCA agent at [client's registered agent contact]. We will investigate and remove infringing content as required by the Digital Millennium Copyright Act.

---

## Workflow for every new site

1. Ask what features the site has: AI chat, forms, e-commerce, tracking pixels, uploads, comments, or reviews.
2. Match those features against the five risk areas above.
3. Generate the Privacy Policy and Terms of Service pages using only the templates that apply. Don't paste in sections for features the site doesn't have.
4. Fill in the data collection table with real answers for that specific client.
5. If UGC applies, flag the DMCA agent registration as a manual to-do for the client before launch. Note the $6 cost and the copyright.gov link.
6. Before publishing, flag the finished legal pages for a quick human review. This checklist covers the common risks. It doesn't replace a lawyer for anything unusual — a regulated industry, a client with existing litigation, an unusual data type.

---

## Source

Built from an Instagram Reel ("Vibecoding lawsuit checklist," @shrug.manny). Treat the templates as a strong starting point, not a legal opinion.
